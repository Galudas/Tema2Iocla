#include<stdio.h>
#include<math.h>

int outsider_var;
char undefined_function(){};
